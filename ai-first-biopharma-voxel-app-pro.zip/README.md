# AI‑First BioPharma — Voxel Journey (Minecraft‑style)

A lightweight, professional yet visionary web app that animates an end‑to‑end AI‑first BioPharma journey in a blocky, voxel (Minecraft‑like) world. It visualizes the storyboard you defined (patient flare → insight hub → clinical loop → field sync → fulfillment → education → KPI → GenAI factory) with a timeline scrubber and auto‑play.

## Stack
- Vite + React
- React Three Fiber (@react-three/fiber) + Drei
- Zustand for app state
- Three.js under the hood

## Quick Start
```bash
npm install
npm run dev
# open the URL printed in your terminal
```

## Project Structure
- `src/storyboard.json` — edit frames, text, chips, and KPIs
- `src/components/*` — voxel scene parts (patient, drone, hologram, insight hub, world)
- `src/App.jsx` — header + canvas + timeline
- `src/components/Scene.jsx` — reads the current frame and toggles scene elements

## Customize
- **Scenes:** Add or remove frames in `storyboard.json`. The overlay & timeline update automatically.
- **Animations:** Enhance movement in `Drone.jsx`, `Patient.jsx`, and others using `useFrame` loops.
- **Branding:** Update palette and fonts in `src/styles.css`.
- **Compliance:** This is a visual demo. Do not use with real PHI. Add your own HIPAA notices and logging if you extend it.

## Roadmap Ideas
- Import GLTF voxel characters/props
- Add voice‑over and captions synced to the timeline
- Record & export a video from the browser (MediaRecorder API)
- Scene transitions (cross‑fade, blur, tilt‑shift)
- Parameterized data input to auto‑generate scenes from a prompt

---

© 2025 — You own this code. MIT‑ish spirit; adapt for your internal demos.

## New Features
- **Voice-over (TTS):** Each frame's `voice` text is spoken using the browser's SpeechSynthesis API. Toggle Mute/Unmute in the footer.
- **Per-frame Durations:** `durationMs` controls autoplay pacing for each frame.
- **Canvas Recording:** Click **Record** to capture the 3D canvas to a WebM video; **Stop** to generate a download link.

## Added in this version
- **Consistent voxel character (MIT asset):** Reusable `VoxelCharacter` ensures continuity across scenes. See `src/assets/LICENSE-MIT.txt`.
- **Word-level captions:** Caption bar overlays VO text; planned support for SpeechSynthesis boundary events.
- **Scene transitions & bloom:** Cross-fade between frames + subtle bloom via `@react-three/postprocessing`.
- **One-click MP4:** Record WebM, then convert in-browser to MP4 using FFmpeg WASM.
- **Prompt → Storyboard:** Paste a concept prompt, auto-generate frames (heuristic) without server calls.

### Notes
- For best MP4 conversion performance, use Chrome/Edge desktop; FFmpeg WASM loads at runtime (~20–30MB).
- Word-level timing is heuristic; browsers expose limited TTS boundary events. Upgrade path: custom VO + SRT.
