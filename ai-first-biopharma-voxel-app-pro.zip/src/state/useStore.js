import { create } from 'zustand'

export const useStore = create((set, get) => ({
  frameIndex: 0,
  playing: false,
  mute: false,
  autoplaySpeed: 4500,
  setFrame: (i) => set({ frameIndex: i }),
  nextFrame: () => {
    const sb = get().storyboard
    const i = get().frameIndex
    if (!sb) return
    set({ frameIndex: (i + 1) % sb.frames.length })
  },
  togglePlay: () => set((s) => ({ playing: !s.playing })),
  toggleMute: () => set((s) => ({ mute: !s.mute })),
  storyboard: null,
  setStoryboard: (sb) => set({ storyboard: sb }),
  // durations from storyboard
  getCurrentDuration: () => {
    const sb = get().storyboard
    const i = get().frameIndex
    const d = sb?.frames?.[i]?.durationMs
    return d || get().autoplaySpeed
  },
  // Recording
  captureProvider: null, // function that returns a MediaStream
  setCaptureProvider: (fn) => set({ captureProvider: fn }),
  recording: false,
  mediaRecorder: null,
  chunks: [],
  videoURL: null,
  startRecording: () => {
    const p = get().captureProvider
    if (!p) return
    const stream = p()
    if (!stream) return
    const mr = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp9' })
    const chunks = []
    mr.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data) }
    mr.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' })
      const url = URL.createObjectURL(blob)
      set({ videoURL: url, chunks: [], mediaRecorder: null, recording: false })
    }
    mr.start()
    set({ mediaRecorder: mr, recording: true, chunks })
  },
  stopRecording: () => {
    const mr = get().mediaRecorder
    if (mr && mr.state !== 'inactive') mr.stop()
  },
  clearVideo: () => set({ videoURL: null }),
}))
