import React, { useEffect } from 'react'
import Scene from './components/Scene.jsx'
import Timeline from './components/Timeline.jsx'
import PromptToStoryboard from './components/PromptToStoryboard.jsx'
import { useStore } from './state/useStore.js'
import sb from './storyboard.json'

export default function App() {
  const { setStoryboard, storyboard } = useStore()
  useEffect(() => { setStoryboard(sb) }, [setStoryboard])

  return (
    <div className="app">
      <header>
        <div>
          <div className="title">{storyboard?.title || 'AI-First BioPharma'}</div>
          <div className="subtitle">{storyboard?.subtitle || 'Voxel journey'}</div>
        </div>
        <div style={{display:'flex', gap:'8px', alignItems:'center'}}>
          <span className="chip">HIPAA-safe demo UI</span>
          <span className="chip">Voxel style</span>
          <span className="chip">R3F + Vite</span>
          <PromptToStoryboard />
        </div>
      </header>
      <Scene />
      <Timeline />
    </div>
  )
}
