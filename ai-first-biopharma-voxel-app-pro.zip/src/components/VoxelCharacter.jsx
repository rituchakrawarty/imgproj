import React, { useRef } from 'react'
import { useFrame } from '@react-three/fiber'

// MIT-licensed procedural voxel character to ensure consistency across scenes
export default function VoxelCharacter({ position=[0,1,0], pulse=false }) {
  const group = useRef()
  useFrame((s, dt) => {
    if (!group.current) return
    const t = s.clock.getElapsedTime()
    group.current.position.y = position[1] + (pulse ? Math.sin(t*4)*0.05 : 0)
  })

  // sizes
  const skin = '#e8ebff'
  const body = '#8ea0ff'
  const accent = '#6bd7ff'
  return (
    <group ref={group} position={position}>
      {/* legs */}
      <mesh position={[-0.18, 0.2, 0]}>
        <boxGeometry args={[0.22, 0.4, 0.22]} />
        <meshStandardMaterial color={body} />
      </mesh>
      <mesh position={[0.18, 0.2, 0]}>
        <boxGeometry args={[0.22, 0.4, 0.22]} />
        <meshStandardMaterial color={body} />
      </mesh>
      {/* torso */}
      <mesh position={[0, 0.8, 0]}>
        <boxGeometry args={[0.7, 0.8, 0.35]} />
        <meshStandardMaterial color={body} />
      </mesh>
      {/* head */}
      <mesh position={[0, 1.5, 0]}>
        <boxGeometry args={[0.52, 0.52, 0.52]} />
        <meshStandardMaterial color={skin} />
      </mesh>
      {/* arms */}
      <mesh position={[-0.52, 0.85, 0]}>
        <boxGeometry args={[0.22, 0.6, 0.22]} />
        <meshStandardMaterial color={body} />
      </mesh>
      <mesh position={[0.52, 0.85, 0]}>
        <boxGeometry args={[0.22, 0.6, 0.22]} />
        <meshStandardMaterial color={body} />
      </mesh>
      {/* ring highlight (right hand) */}
      <mesh position={[0.7, 0.65, 0]}>
        <torusGeometry args={[0.06, 0.02, 12, 24]} />
        <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={0.9} />
      </mesh>
    </group>
  )
}
