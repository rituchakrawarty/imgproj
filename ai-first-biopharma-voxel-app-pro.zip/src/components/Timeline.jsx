import React, { useEffect, useState } from 'react'
import { useStore } from '../state/useStore.js'
import { speak, stopSpeaking } from '../utils/tts.js'
import { webmToMp4 } from '../utils/ffmpeg.js'

export default function Timeline() {
  const { storyboard, frameIndex, setFrame, playing, togglePlay, nextFrame, getCurrentDuration, mute,
    toggleMute, startRecording, stopRecording, recording, videoURL, clearVideo } = useStore()
  const [mp4URL, setMp4URL] = useState(null)

  useEffect(() => {
    if (!playing) return
    const timeout = setTimeout(() => nextFrame(), getCurrentDuration())
    return () => clearTimeout(timeout)
  }, [playing, frameIndex, nextFrame, getCurrentDuration])

  useEffect(() => {
    if (!storyboard) return
    const frame = storyboard.frames[frameIndex]
    if (!frame) return
    if (!mute) speak(frame.voice, { rate: 1.0 })
    return () => stopSpeaking()
  }, [frameIndex, storyboard, mute])

  if (!storyboard) return null

  const transcode = async () => {
    if (!videoURL) return
    const res = await fetch(videoURL)
    const blob = await res.blob()
    const out = await webmToMp4(blob)
    setMp4URL(URL.createObjectURL(out))
  }

  return (
    <footer>
      <div className="timeline">
        {storyboard.frames.map((f, i) => (
          <button key={f.id} className={"frame-btn " + (i===frameIndex ? "active": "")} onClick={() => setFrame(i)}>
            {i+1}. {f.label}
          </button>
        ))}
      </div>
      <div className="controls">
        <button className="frame-btn" onClick={() => setFrame(Math.max(0, frameIndex-1))}>◀ Prev</button>
        <button className="frame-btn" onClick={() => setFrame(Math.min(storyboard.frames.length-1, frameIndex+1))}>Next ▶</button>
        <button className="frame-btn" onClick={togglePlay}>{playing ? "Pause" : "Auto-play"}</button>
        <button className="frame-btn" onClick={toggleMute}>{mute ? "Unmute VO" : "Mute VO"}</button>
        {!recording && <button className="cta" onClick={startRecording}>● Record</button>}
        {recording && <button className="cta" onClick={stopRecording}>■ Stop</button>}
        {videoURL && <a className="frame-btn" href={videoURL} download="ai-first-journey.webm" onClick={clearVideo}>Download WebM</a>}
        {videoURL && <button className="frame-btn" onClick={transcode}>Convert to MP4</button>}
        {mp4URL && <a className="cta" href={mp4URL} download="ai-first-journey.mp4">Download MP4</a>}
      </div>
    </footer>
  )
}
