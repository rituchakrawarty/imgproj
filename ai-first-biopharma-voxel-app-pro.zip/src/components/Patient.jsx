import React, { useRef } from 'react'
import { useFrame } from '@react-three/fiber'

export default function Patient({ showRing=false, painPulse=false }) {
  const arm = useRef()
  useFrame((s, dt) => {
    if (!arm.current) return
    const t = s.clock.getElapsedTime()
    arm.current.rotation.z = -0.2 + (painPulse ? Math.sin(t*6)*0.1 : 0)
  })

  return (
    <group position={[-2, 1, 0]}>
      {/* body */}
      <mesh position={[0,0.8,0]}>
        <boxGeometry args={[0.8, 1.6, 0.4]} />
        <meshStandardMaterial color={'#9aa7ff'} />
      </mesh>
      {/* head */}
      <mesh position={[0,1.8,0]}>
        <boxGeometry args={[0.6, 0.6, 0.6]} />
        <meshStandardMaterial color={'#e8ebff'} />
      </mesh>
      {/* arm */}
      <group ref={arm} position={[0.5,1.2,0]}>
        <mesh>
          <boxGeometry args={[0.9, 0.25, 0.25]} />
          <meshStandardMaterial color={'#9aa7ff'} />
        </mesh>
        {showRing && (
          <mesh position={[0.45,0,0]}>
            <torusGeometry args={[0.06, 0.02, 12, 24]} />
            <meshStandardMaterial color={'#6bd7ff'} emissive={'#6bd7ff'} emissiveIntensity={0.8} />
          </mesh>
        )}
      </group>
    </group>
  )
}
