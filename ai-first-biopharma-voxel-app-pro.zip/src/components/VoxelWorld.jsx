import React, { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

// Simple voxel ground + a few towers to give a Minecraft‑like vibe
export default function VoxelWorld({ palette = [0x7aa2ff, 0x9aa7ff, 0x6bd7ff] }) {
  const group = useRef()
  useFrame((_, dt) => {
    if (group.current) group.current.rotation.y += dt * 0.02
  })

  const blocks = []
  const size = 12
  for (let x = -size; x <= size; x++) {
    for (let z = -size; z <= size; z++) {
      if ((x+z) % 4 === 0) {
        blocks.push([x, 0, z, 0x1b2345]) // ground studs
      }
    }
  }
  // a few towers
  for (let i = 0; i < 6; i++) {
    const h = 2 + Math.floor(Math.random() * 6)
    const x = -10 + i * 4
    const z = i % 2 === 0 ? -6 : 6
    for (let y = 1; y <= h; y++) {
      blocks.push([x, y, z, palette[i % palette.length]])
    }
  }

  return (
    <group ref={group}>
      {blocks.map((b, idx) => (
        <mesh key={idx} position={[b[0], b[1], b[2}]}>
          <boxGeometry args={[0.9, 0.9, 0.9]} />
          <meshStandardMaterial color={b[3]} roughness={0.8} metalness={0.1} />
        </mesh>
      ))}
      {/* soft base plane */}
      <mesh rotation={[-Math.PI/2, 0, 0]} position={[0, -0.5, 0]} receiveShadow>
        <planeGeometry args={[80, 80]} />
        <meshStandardMaterial color={'#0a0f1f'} />
      </mesh>
    </group>
  )
}
