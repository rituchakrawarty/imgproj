import React, { useRef } from 'react'
import { useFrame } from '@react-three/fiber'

export default function HologramClinician({ visible=false }) {
  const ref = useRef()
  useFrame((state, dt) => {
    if (!ref.current) return
    const t = state.clock.getElapsedTime()
    ref.current.material.opacity = visible ? 0.65 + Math.sin(t*8)*0.05 : 0.0
  })
  return (
    <mesh position={[2.2, 1.2, 0]}>
      <boxGeometry args={[0.8, 1.6, 0.2]} />
      <meshStandardMaterial ref={ref} color={'#6bd7ff'} transparent opacity={0.0} emissive={'#6bd7ff'} emissiveIntensity={0.5} />
    </mesh>
  )
}
