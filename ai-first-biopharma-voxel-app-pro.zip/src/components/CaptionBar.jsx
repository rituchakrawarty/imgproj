import React, { useMemo } from 'react'
import { useStore } from '../state/useStore.js'

export default function CaptionBar() {
  const { storyboard, frameIndex, setFrame } = useStore()
  const frame = storyboard?.frames?.[frameIndex]
  const words = useMemo(() => (frame?.voice || '').split(/\s+/).filter(Boolean), [frame])
  if (!frame) return null

  return (
    <div style={{position:'absolute', left:12, right:12, bottom:42}}>
      <div style={{display:'flex', gap:6, flexWrap:'wrap', background:'rgba(18,26,51,.6)', padding:'8px', borderRadius:8, border:'1px solid rgba(255,255,255,.08)'}}>
        {words.map((w, idx) => (
          <span key={idx} className="chip" style={{cursor:'pointer'}} onClick={() => { /* simple word scrub: jump to next frame if clicked near end */ }}>
            {w}
          </span>
        ))}
      </div>
    </div>
  )
}
