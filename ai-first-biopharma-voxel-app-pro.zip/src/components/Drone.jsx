import React, { useRef } from 'react'
import { useFrame } from '@react-three/fiber'

export default function Drone({ active=false }) {
  const ref = useRef()
  useFrame((s, dt) => {
    if (!ref.current) return
    const t = s.clock.getElapsedTime()
    ref.current.position.y = 2 + Math.sin(t * 2) * 0.2
    if (active) {
      ref.current.position.x = Math.sin(t) * 3
      ref.current.position.z = Math.cos(t) * 3
    }
  })
  return (
    <group ref={ref} position={[0,2,0]}>
      <mesh>
        <boxGeometry args={[1.2, 0.3, 1.2]} />
        <meshStandardMaterial color={'#7aa2ff'} />
      </mesh>
      <mesh position={[-0.6, 0.3, -0.6]}>
        <cylinderGeometry args={[0.15, 0.15, 0.05, 16]} />
        <meshStandardMaterial color={'#c9d4ff'} />
      </mesh>
      <mesh position={[0.6, 0.3, -0.6]}>
        <cylinderGeometry args={[0.15, 0.15, 0.05, 16]} />
        <meshStandardMaterial color={'#c9d4ff'} />
      </mesh>
      <mesh position={[-0.6, 0.3, 0.6]}>
        <cylinderGeometry args={[0.15, 0.15, 0.05, 16]} />
        <meshStandardMaterial color={'#c9d4ff'} />
      </mesh>
      <mesh position={[0.6, 0.3, 0.6]}>
        <cylinderGeometry args={[0.15, 0.15, 0.05, 16]} />
        <meshStandardMaterial color={'#c9d4ff'} />
      </mesh>
    </group>
  )
}
