import React, { useMemo } from 'react'

export default function InsightHub({ active=false }) {
  const nodes = useMemo(() => {
    const n = []
    for (let i=0;i<20;i++) {
      n.push({
        x: -0.5 + Math.random()*1.0,
        y: 0.5 + Math.random()*1.0,
        z: -0.5 + Math.random()*1.0
      })
    }
    return n
  }, [])

  return (
    <group position={[0, 1, -2]}>
      {nodes.map((p, idx) => (
        <mesh key={idx} position={[p.x, p.y, p.z]}>
          <boxGeometry args={[0.1,0.1,0.1]} />
          <meshStandardMaterial color={active ? '#7aa2ff' : '#3a4477'} />
        </mesh>
      ))}
      <mesh position={[0,0,0]}>
        <boxGeometry args={[1.8, 0.2, 1.2]} />
        <meshStandardMaterial color={'#1b2345'} />
      </mesh>
    </group>
  )
}
