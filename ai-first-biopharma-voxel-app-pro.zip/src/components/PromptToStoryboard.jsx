import React, { useState } from 'react'
import { useStore } from '../state/useStore.js'

function heuristicGenerate(text) {
  // Lightweight prompt parser → frames
  const base = [
    { id:'opening', label:'Why Change', voice:'In five years, decisions move at the speed of a prompt.', summary:'Fast-cut headlines and signals of super-intelligence.', chips:['Strategy','Super-intelligence'] },
    { id:'sarah-home', label:'Patient Trigger', voice:'One thing hasn’t changed: pain. Sarah’s still hurts.', summary:'Patient struggles, wearable flags flare.', chips:['Patient','Wearable'] },
    { id:'insight-hub', label:'Edge → Insight Hub', voice:'Edge data flows into our AI insight hub in real time.', summary:'Data streams to dashboards.', chips:['Insights','Privacy'] },
    { id:'clinical-loop', label:'Clinical Decision', voice:'Guidelines and costs resolve to one clear answer.', summary:'Evidence note drafted for PCP; co-pay verified.', chips:['Medical','Access'] },
    { id:'field-sync', label:'Field Sync', voice:'Every stakeholder sees the same truth—instantly.', summary:'CRM agent prepares tailored detailing.', chips:['Field','CRM'] },
    { id:'fulfillment', label:'Autonomous Fulfillment', voice:'Therapy moves with zero friction across the chain.', summary:'Robotic hub → drone dispatch.', chips:['Supply','Drone'] },
    { id:'education', label:'Education', voice:'Clear guidance builds confidence and adherence.', summary:'Hologram clinician explains dosage.', chips:['Services','Twin'] },
    { id:'kpis', label:'Impact', voice:'Outcomes improve—for the patient and the system.', summary:'KPIs overlay.', chips:['KPI','Value'] },
    { id:'blueprint', label:'GenAI Factory', voice:'AI-first becomes the operating system.', summary:'Unified blueprint of data + models.', chips:['Factory','Governance'] },
  ]
  // If text contains certain keywords, lightly tweak labels/voices
  const lower = text.toLowerCase()
  if (lower.includes('market access')) base[3].chips.push('Market Access')
  if (lower.includes('salesforce')) base[4].chips.push('Salesforce')
  if (lower.includes('drone')) base[5].chips.push('Logistics')
  return {
    title: 'AI-First BioPharma — Generated',
    subtitle: text.slice(0, 80) + (text.length>80?'…':''),
    frames: base.map((f, i) => ({ ...f, durationMs: 4200 })),
    kpis: [
      { label:'Time-to-Therapy', value:'-90%' },
      { label:'Adherence', value:'+20%' },
      { label:'Cost-per-Flare', value:'-30%' }
    ]
  }
}

export default function PromptToStoryboard() {
  const [open, setOpen] = useState(false)
  const [text, setText] = useState('')
  const { setStoryboard } = useStore()
  const onGen = () => {
    const sb = heuristicGenerate(text || '')
    setStoryboard(sb)
    setOpen(false)
  }
  return (
    <>
      <button className="frame-btn" onClick={() => setOpen(true)}>Prompt → Storyboard</button>
      {open && (
        <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.5)', display:'grid', placeItems:'center', zIndex:50}}>
          <div style={{background:'#121a33', border:'1px solid rgba(255,255,255,.1)', padding:16, width:600, borderRadius:12}}>
            <h3 style={{marginTop:0}}>Generate Storyboard from Prompt</h3>
            <textarea rows={8} style={{width:'100%', background:'#0b1020', color:'#e8ebff', border:'1px solid rgba(255,255,255,.1)', borderRadius:8, padding:8}} value={text} onChange={e=>setText(e.target.value)} placeholder="Paste your concept prompt here…" />
            <div style={{display:'flex', gap:8, justifyContent:'flex-end', marginTop:10}}>
              <button className="frame-btn" onClick={()=>setOpen(false)}>Cancel</button>
              <button className="cta" onClick={onGen}>Generate</button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
