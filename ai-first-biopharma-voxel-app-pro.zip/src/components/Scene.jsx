import React, { Suspense, useEffect, useRef, useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { Environment, OrbitControls, ContactShadows } from '@react-three/drei'
import { EffectComposer, Bloom } from '@react-three/postprocessing'
import { useStore } from '../state/useStore.js'
import VoxelWorld from './VoxelWorld.jsx'
import Drone from './Drone.jsx'
import HologramClinician from './HologramClinician.jsx'
import InsightHub from './InsightHub.jsx'
import VoxelCharacter from './VoxelCharacter.jsx'
import CaptionBar from './CaptionBar.jsx'

function CaptureRegistrar({ setCaptureProvider }) {
  const ref = useRef(null)
  useEffect(() => {
    // find canvas after mount
    const canvas = document.querySelector('canvas')
    if (!canvas) return
    setCaptureProvider(() => () => canvas.captureStream(30))
  }, [setCaptureProvider])
  return null
}

function SceneObjects({ frameId }) {
  return (
    <group>
      <ambientLight intensity={0.6} />
      <directionalLight intensity={1.0} position={[5,8,5]} castShadow />
      <VoxelWorld />
      {/* Consistent character */}
      <VoxelCharacter position={[-2,1,0]} pulse={frameId==='sarah-home'} />
      <InsightHub active={frameId==='insight-hub' || frameId==='clinical-loop'} />
      <Drone active={frameId==='fulfillment'} />
      <HologramClinician visible={frameId==='education'} />
      <ContactShadows position={[0,0,0]} opacity={0.35} scale={20} blur={1.2} far={6} />
      <Environment preset="city" />
      <OrbitControls enablePan enableRotate enableZoom />
      <EffectComposer>
        <Bloom intensity={1.0} luminanceThreshold={0.2} luminanceSmoothing={0.9} />
      </EffectComposer>
    </group>
  )
}

export default function Scene() {
  const { storyboard, frameIndex, setCaptureProvider } = useStore()
  const frame = storyboard?.frames?.[frameIndex]
  const [fade, setFade] = useState(1)

  // Cross-fade on frame change
  useEffect(() => {
    setFade(0)
    const a = requestAnimationFrame(() => {
      setFade(1)
    })
    return () => cancelAnimationFrame(a)
  }, [frameIndex])

  return (
    <div className="canvas-wrap">
      <Canvas shadows camera={{ position: [5,5,10], fov: 45 }}>
        <Suspense fallback={null}>
          <SceneObjects frameId={frame?.id} />
          <CaptureRegistrar setCaptureProvider={setCaptureProvider} />
        </Suspense>
      </Canvas>

      {/* Overlay panels */}
      <div style={{position:'absolute', inset:0, background:`rgba(11,16,32,${1-fade})`, pointerEvents:'none', transition:'background 400ms ease'}} />

      {frame && (
        <div className="overlay">
          <h3>{frame.label}</h3>
          <p>{frame.summary}</p>
          <div className="chips">
            {frame.chips?.map((c, i) => <span key={i} className="chip">{c}</span>)}
          </div>
          <div style={{marginTop:8, fontSize:12, opacity:.9}}>
            <strong>VO:</strong> {frame.voice}
          </div>
        </div>
      )}

      <CaptionBar />

      {storyboard?.kpis && (
        <div className="kpis">
          {storyboard.kpis.map((k, i) => (
            <div key={i} className="kpi"><strong>{k.label}</strong><div>{k.value}</div></div>
          ))}
        </div>
      )}
    </div>
  )
}
