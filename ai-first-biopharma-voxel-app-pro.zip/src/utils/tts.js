// Simple browser TTS helper using SpeechSynthesis
export function speak(text, opts = {}) {
  if (!('speechSynthesis' in window)) return
  if (!text) return
  const u = new SpeechSynthesisUtterance(text)
  u.rate = opts.rate ?? 1.0
  u.pitch = opts.pitch ?? 1.0
  u.lang = opts.lang ?? 'en-US'
  if (opts.voiceName) {
    const pick = speechSynthesis.getVoices().find(v => v.name.includes(opts.voiceName))
    if (pick) u.voice = pick
  }
  window.speechSynthesis.cancel()
  window.speechSynthesis.speak(u)
}

export function stopSpeaking() {
  if (!('speechSynthesis' in window)) return
  window.speechSynthesis.cancel()
}
