import { createFFmpeg, fetchFile } from '@ffmpeg/ffmpeg'

let ffmpeg = null

export async function ensureFFmpeg() {
  if (!ffmpeg) {
    ffmpeg = createFFmpeg({ log: false })
    await ffmpeg.load()
  }
  return ffmpeg
}

export async function webmToMp4(webmBlob) {
  const ff = await ensureFFmpeg()
  const data = new Uint8Array(await webmBlob.arrayBuffer())
  ff.FS('writeFile', 'input.webm', data)
  await ff.run('-i', 'input.webm', '-c:v', 'libx264', '-preset', 'veryfast', '-pix_fmt', 'yuv420p', 'out.mp4')
  const out = ff.FS('readFile', 'out.mp4')
  return new Blob([out.buffer], { type: 'video/mp4' })
}
