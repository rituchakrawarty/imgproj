let
    SiteUrl = #"(Parameter) SharePointSiteUrl",
    LibraryPathFilter = try #"(Parameter) LibraryFilter" otherwise "",
    DoHash = try #"(Parameter) ComputeHash" otherwise false,
    Source = SharePoint.Files(SiteUrl, [ApiVersion=15]),
    Filtered = if (LibraryPathFilter = null or LibraryPathFilter = "") then Source else Table.SelectRows(Source, each Text.Contains([Folder Path], LibraryPathFilter)),
    Selected = Table.SelectColumns(Filtered, {"Name","Extension","Folder Path","Path","Date accessed","Date created","Date modified","Attributes","Content","Size"}),
    AddedFileName = Table.AddColumn(Selected, "file_name", each [Name], type text),
    AddedExt = Table.AddColumn(AddedFileName, "ext", each Text.Lower([Extension]?), type text),
    AddedItemUrl = Table.AddColumn(AddedExt, "item_url", each [Path], type text),
    AddedLibrary = Table.AddColumn(AddedItemUrl, "library", each let parts = Text.Split([Folder Path], "/") in if List.Count(parts) > 4 then parts{4} else parts{List.Count(parts)-1}, type text),
    RenamedDates = Table.TransformColumnTypes(AddedLibrary, {{"Date created", type datetime}, {"Date modified", type datetime}, {"Date accessed", type datetime}}),
    Now = DateTimeZone.RemoveZone(DateTimeZone.FixedUtcNow()),
    AddedStaleDays = Table.AddColumn(RenamedDates, "stale_days", each try Duration.Days(Now - [Date modified]) otherwise null, Int64.Type),
    Hashed = if DoHash then Table.AddColumn(AddedStaleDays, "doc_hash_md5", each try Binary.ToText(Binary.Hash([Content], "MD5"), BinaryEncoding.Hex) otherwise null, type text) else Table.AddColumn(AddedStaleDays, "doc_hash_md5", each null, type text),
    AddedRagEligible = Table.AddColumn(Hashed, "rag_eligible_hint", each let ok = {"docx","pptx","pdf","xlsx","csv","txt","md"} in if List.Contains(ok, [ext]) then "Yes" else "Needs Review", type text),
    Removed = Table.RemoveColumns(AddedRagEligible, {"Attributes","Content"}),
    Reordered = Table.ReorderColumns(Removed, {"item_url","library","file_name","ext","Size","Date created","Date modified","Date accessed","stale_days","doc_hash_md5","rag_eligible_hint","Folder Path","Path","Name","Extension"})
in
    Reordered