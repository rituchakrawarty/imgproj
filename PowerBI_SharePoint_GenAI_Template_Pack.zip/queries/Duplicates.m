let
    Source = Inventory,
    HasHash = Table.SelectRows(Source, each [doc_hash_md5] <> null and [doc_hash_md5] <> ""),
    Grouped = Table.Group(HasHash, {"doc_hash_md5"}, {{"rows", each _, type table}}),
    WithCounts = Table.AddColumn(Grouped, "dup_count", each Table.RowCount([rows]), Int64.Type),
    Expanded = Table.ExpandTableColumn(WithCounts, "rows", {"item_url","file_name","ext","Date modified","library"}, {"item_url","file_name","ext","Date modified","library"}),
    FilterDupes = Table.SelectRows(Expanded, each [dup_count] > 1),
    Sorted = Table.Sort(FilterDupes,{{"doc_hash_md5", Order.Ascending},{"Date modified", Order.Descending}}),
    AddedCanonical = Table.Group(Sorted, {"doc_hash_md5"}, {{"CanonicalRow", each Table.FirstN(Table.Sort(_,{{"Date modified", Order.Descending}}),1), type table},{"AllRows", each _, type table}}),
    ExpandedCanon = Table.ExpandTableColumn(AddedCanonical, "CanonicalRow", {"item_url"}, {"canonical_item_url"}),
    ExpandedAll = Table.ExpandTableColumn(ExpandedCanon, "AllRows", {"item_url","file_name","ext","Date modified","library","dup_count"}, {"item_url","file_name","ext","Date modified","library","dup_count"}),
    Marked = Table.AddColumn(ExpandedAll, "is_canonical", each [item_url] = [canonical_item_url], type logical)
in
    Marked