let
    FolderPath = #"(Parameter) AuditCsvFolderPath",
    Source = Folder.Files(FolderPath),
    CsvOnly = Table.SelectRows(Source, each Text.Lower([Extension]) = ".csv"),
    Imported = Table.AddColumn(CsvOnly, "Table", each Csv.Document(File.Contents([Folder Path] & [Name]),[Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv])),
    Expanded = Table.ExpandTableColumn(Imported, "Table", {"Column1","Column2","Column3","Column4","Column5","Column6","Column7"}, {"CreationTime","UserId","Operation","SiteUrl","SourceFileName","SourceRelativeUrl","ObjectId"}),
    ToTypes = Table.TransformColumnTypes(Expanded,{{"CreationTime", type datetime}}),
    Clean = Table.RemoveColumns(ToTypes, {"Content"})
in
    Clean