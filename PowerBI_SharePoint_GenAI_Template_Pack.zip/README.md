# Power BI Template Pack — SharePoint GenAI Readiness

**Parameters to create in Power BI Desktop:**
- SharePointSiteUrl (Text) — e.g., https://tenant.sharepoint.com/sites/YourSite
- LibraryFilter (Text) — optional partial path match
- ComputeHash (True/False)
- AuditCsvFolderPath (Text, optional)

**Queries:** Inventory, Duplicates, AuditLogs.  **Theme:** GenAITheme.json  **DAX:** Measures.dax